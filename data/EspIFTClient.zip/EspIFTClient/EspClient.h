#ifndef ESP_CLIENT_H
#define ESP_CLIENT_H
#include <SoftwareSerial.h>

#define STATION_MODE  1

// #define DEBUG
class EspClient {
public:
  EspClient(int rx_pin, int tx_pin);
  void begin(int baud);
  int  atCommand(char *cmd, int wait_time);
  int  atCwMode(int mode);
  int  atCwJap(char *ssid, char *passwd);
  int  atCipStart(char *server_addr, int server_port);
  int  atCipSend(char *uri, char *host);
  int  atRest();
  void atClose();
  void println(char *s);
protected:
  int  waitForResponse();
  static const int  interval_waits[8];
  static const int  retry_count;
private:
  char            buf[256];
  int             last_char;
  SoftwareSerial  esp;
};

#endif /* ESP_CLIENT_H */
