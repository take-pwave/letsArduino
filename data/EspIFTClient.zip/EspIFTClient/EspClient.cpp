#include "EspClient.h"
#include "Arduino.h"

#define CRLF          "\r\n"
#define CRLF2         "\r\n\r\n"

#define WAIT_ONECE    2000
#define OK            'K'
#define ERR           'R'
#define FAIL          'L'

const int  EspClient::interval_waits[8] = {20, 40, 60, 100, 150, 300, 600, 1500};
const int  EspClient::retry_count = sizeof(interval_waits)/sizeof(int);  

  
EspClient::EspClient(int rx_pin, int tx_pin) : esp(rx_pin, tx_pin) {
}

void EspClient::begin(int baud) {
  Serial.begin(baud);
  while (!Serial) {
    ; // wait for serial port to connect. Needed for Leonardo only
  }
  esp.begin(baud);
}

int  EspClient::waitForResponse() {
  int c;
  last_char = -1;
  int err_count = 0;
  // 返されたデータをすべて読み込む
  for (int i = 0; i < retry_count; i++) {
    while (esp.available()) {
      while((c = esp.read()) != -1) { 
        if (c != '\r' && c != '\n')
          last_char = c;
        // デバッグ用
        Serial.write(c);
      } 
    }
    // OK, ERROR, > , FAIL, CLOSED
    if (last_char == OK || last_char == ERR || last_char == ' ' || last_char == 'L' || last_char == 'D') break;
    // Serial.println("wait");
    delay(interval_waits[err_count++]);
  }
}

int  EspClient::atCommand(char *cmd, int wait_time) {
  int c;
  
  esp.print(cmd);
  esp.print(CRLF);
  delay(wait_time);
  // 応答を待つ
  waitForResponse();
  // 最後に返された文字がKまたはRでなかったら、WAIT_ONECEミリ秒待つ
  if (last_char != OK && last_char != ERR && last_char != ' ') {
    delay(WAIT_ONECE);
    Serial.println("Do wait onece");
    if (esp.available()) {
      while((c = esp.read()) != -1) { 
        if (c != '\r' || c != '\n')
          last_char = c;
        // デバッグ用
        Serial.write(c);
      } 
    }
  }
  if (last_char == OK)
    return 1;
  else if (last_char == ERR)
    return 0;
  else
    return -1;
}

int  EspClient::atCwMode(int mode) {
  sprintf(buf, "AT+CWMODE=%d", mode);
  return atCommand(buf, 0);
}

int  EspClient::atCwJap(char *ssid, char *passwd) {
  sprintf(buf, "AT+CWJAP=\"%s\",\"%s\"", ssid, passwd);
  return atCommand(buf, 2000);
}

int  EspClient::atCipStart(char *server_addr, int server_port) {
  sprintf(buf, "AT+CIPSTART=\"TCP\",\"%s\",%d", server_addr, server_port);
  return atCommand(buf, 500);
}

int  EspClient::atCipSend(char *uri, char *host) {
  sprintf(buf, "GET %s HTTP/1.1\r\nHost: %s\r\nAccept: */*\r\n%s", uri, host, CRLF2);
  int len = strlen(buf);
  char tmp[32];
  sprintf(tmp, "AT+CIPSEND=%d%s", len, CRLF);
  // uriを送る
  atCommand(tmp, 1000);
  esp.print(buf);
  // 応答を待つ
  waitForResponse();
}

int  EspClient::atRest() {
  return -1;  // 未実装
}

void EspClient::atClose() {
}

void EspClient::println(char *s) {
  Serial.println(s);
}
