#ifndef  __KEYBOARD_H__
#define  __KEYBOARD_H__
#include "types.h"

#define  NO_KEY	0

class KeyBoard {
public:
  KeyBoard() {
	  lastkey = 1;
	  code = -1;
	  cnt = 0;
  }
  int getKey() {
    return cnt++%2 == 0 ? 1 : 0;
  }

  int  getCode() {
    return 2;
  }

  int  lastKey() {
    return 1;
  }

private:
  int   lastkey;
  byte  code;
  int	cnt;
};

#endif
