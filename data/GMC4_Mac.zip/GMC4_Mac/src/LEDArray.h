#ifndef  __LED_ARRAY_H__
#define  __LED_ARRAY_H__
#include "types.h"

class LEDArray {
public:
  LEDArray() {
	  value = 0;
	  state = 0;
  }

  void setup() {
  }

  void on() {
	state = 1;
  }

  void off() {
	state = 0;
  }

  void draw() {
	  printf("Display led array: %1x\n", value);
  }

  void setAddress(byte addr) {
	value = addr;
  }

  byte getAddress() {
    return value;
  }

private:
  byte  value;
  byte	state;
};

#endif
