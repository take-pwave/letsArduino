#ifndef  __LED_7SEG_H__
#define  __LED_7SEG_H__

#include <stdio.h>
#include "types.h"

class LED7Seg {
public:
  LED7Seg() {
	value = 0;
	state = 0;
  }

  void setup() {
  }

  void on() {
    state = 1;
  }

  void off() {
	state = 0;
  }

  void draw() {
	  printf("Display 7Seg: %1x\n", value);
  }

  void clear() {
    value = 0;
  }

  void setValue(byte val) {
    value = val;
    draw();
  }

  byte getValue() {
	  return value;
  }

private:
  byte   value;
  byte	 state;
};

#endif
