//============================================================================
// Name        : GMC4_Mac.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <stdio.h>

#include "GMC4.h"
LEDArray  ledArray;
LED7Seg   led7Seg;
KeyBoard  keyBoard;
GMC4      gmc4(&keyBoard, &ledArray, &led7Seg);

byte lastCode;
byte addr;
byte mode;

int main() {
	gmc4.setMode(RUN_LedOffBeepOff);
	while(gmc4.step() != PROGRAM) {
		printf("address = %02x: value=%1x, ledarray=%02x\n", gmc4.getAddr(), led7Seg.getValue(), ledArray.getAddress());
	}

	return 0;
}
