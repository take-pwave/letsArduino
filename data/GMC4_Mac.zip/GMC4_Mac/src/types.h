#ifndef	__MY_TYPES_H__
#define	__MY_TYPES_H__

typedef	 unsigned char byte;

#define	tone(a, b, c)
#define	delay(a)

#endif
