#ifndef  __KEYBOARD_H__
#define  __KEYBOARD_H__

#include <Keypad.h>

const byte rows = 5; // 5行
const byte cols = 4; // 4列

class KeyBoard {
public:
  int getKey() {
    char key = keypad.getKey();
    if (key != NO_KEY) {
      code = -1;
      if ((key >= '0' && key <= '9') || (key >= 'A' && key <= 'F')) 
        code = key <= '9' ? key - '0' : key - 'A' + 10;
      lastkey = key;
    }
      
    return key;
  }
  
  boolean isPressed() {
    return keypad.getState() == HOLD;
  }
  
  int  getCode() {
    return code;
  }
  
  int  lastKey() {
    return lastkey;
  }
  
private:
  char  lastkey = NO_KEY;
  byte  code = -1;
  char keys[rows][cols] = {
    {'S','I','R','T'},
    {'C','D','E','F'},
    {'8','9','A','B'},
    {'4','5','6','7'},
    {'0','1','2','3'}
  };
  PinName	rowPins[rows] = {D12, D10, D7, D11, D2};
  PinName	colPins[cols] = {D4, D5, D6, D13};
  Keypad	keypad = Keypad( makeKeymap(keys), rowPins, colPins, rows, cols );
};

#endif
