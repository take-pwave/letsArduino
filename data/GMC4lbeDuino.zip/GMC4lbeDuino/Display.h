#ifndef  __DISPLAY_H__
#define  __DISPLAY_H__
#include "lbed.h"
#include "AQCM0802.h"

class Display {
public:
  Display() : _lcd(D8, D9) {
    //setup();
  }
  
  void setup() {
    _lcd.setup();
    _lcd.cls();
    _lcd.locate(0, 0);
    _lcd.print("Addr: ");
    _lcd.locate(0, 1);
    _lcd.print("Value: ");
  }
  
  void clear() {
    _lcd.cls();
  }
  
  void drawValue() {
    _lcd.locate(7, 1);
    _lcd.print(_value, HEX);
  }
  
  void drawAddr() {
    _lcd.locate(6, 0);
    if (_addr <= 0xF)
      _lcd.print(0);
    _lcd.print(_addr, HEX);
  }
  
  void setAddress(byte addr) {
    _addr = addr;
  }
  
  byte getAddress() {
    return _addr;
  }
  
  void setValue(byte value) {
    _value = value;
  }
  
  byte getValue() {
    return _value;
  }
private:
  byte      _value = 0;
  byte      _addr = 0;  
  AQCM0802  _lcd;
};
#endif

